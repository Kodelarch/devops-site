"""Настройки из переменных окружения (12-factor)."""

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    database_url: str | None
    log_level: str = "INFO"

    @classmethod
    def from_env(cls) -> "Settings":
        level = os.environ.get("LOG_LEVEL", "INFO").upper()
        if level not in {"DEBUG", "INFO", "WARNING", "ERROR"}:
            raise SystemExit(f"LOG_LEVEL должен быть DEBUG, INFO, WARNING или ERROR, получено {level!r}")
        # Без DATABASE_URL сервис работает на демо-данных в памяти — удобно для первого запуска.
        return cls(database_url=os.environ.get("DATABASE_URL") or None, log_level=level)
