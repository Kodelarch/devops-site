"""Понятия и правила магазина. Ничего не знает про HTTP, базу данных и терминал."""

from dataclasses import dataclass
from decimal import Decimal


class ShopError(Exception):
    """Базовая ошибка домена: веб-слой превращает её наследников в коды HTTP."""


class InvalidOrder(ShopError):
    pass


class ProductNotFound(ShopError):
    def __init__(self, product_id: int):
        super().__init__(f"товар {product_id} не найден")
        self.product_id = product_id


class OutOfStock(ShopError):
    def __init__(self, product_id: int):
        super().__init__(f"товара {product_id} нет в нужном количестве")
        self.product_id = product_id


@dataclass(frozen=True)
class Product:
    id: int
    store_id: int
    title: str
    price: Decimal
    stock: int


@dataclass(frozen=True)
class OrderLine:
    product_id: int
    title: str
    price: Decimal
    qty: int

    @property
    def total(self) -> Decimal:
        return self.price * self.qty


@dataclass
class Order:
    customer_id: int
    lines: list[OrderLine]
    id: int | None = None

    @property
    def total(self) -> Decimal:
        return sum((line.total for line in self.lines), Decimal("0"))


def normalize_items(items) -> list[tuple[int, int]]:
    """Проверить позиции заказа и сложить повторы одного товара.

    Возвращает список (product_id, qty), отсортированный по product_id:
    единый порядок списания защищает от взаимных блокировок в базе.
    """
    if not isinstance(items, list) or not items:
        raise InvalidOrder("нужен непустой список items")
    merged: dict[int, int] = {}
    for item in items:
        try:
            product_id, qty = int(item["product_id"]), int(item["qty"])
        except (KeyError, TypeError, ValueError):
            raise InvalidOrder("каждая позиция должна содержать product_id и qty") from None
        if qty <= 0:
            raise InvalidOrder("qty должен быть больше нуля")
        merged[product_id] = merged.get(product_id, 0) + qty
    return sorted(merged.items())


class OrderService:
    """Сценарий оформления заказа. Хранилище передаётся снаружи (dependency injection)."""

    def __init__(self, repository):
        self.repository = repository

    def place_order(self, customer_id, items) -> Order:
        try:
            customer_id = int(customer_id)
        except (TypeError, ValueError):
            raise InvalidOrder("нужен customer_id") from None
        return self.repository.create_order(customer_id, normalize_items(items))
