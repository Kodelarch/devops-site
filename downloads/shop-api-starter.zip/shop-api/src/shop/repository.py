"""Хранилища товаров и заказов: в памяти (для тестов и демо) и PostgreSQL."""

from decimal import Decimal
from threading import Lock

from .domain import InvalidOrder, Order, OrderLine, OutOfStock, Product, ProductNotFound


class InMemoryRepository:
    def __init__(self, products: list[Product], customers: set[int] | None = None):
        self._products = {p.id: p for p in products}
        self._customers = customers
        self._orders: list[Order] = []
        self._lock = Lock()

    @classmethod
    def demo(cls) -> "InMemoryRepository":
        return cls(
            [
                Product(1, 1, "SSD 1 ТБ", Decimal("7490.00"), 12),
                Product(3, 1, "Видеокарта", Decimal("54990.00"), 5),
                Product(7, 3, "Роутер Wi-Fi 6", Decimal("5490.00"), 15),
                Product(12, 4, "Мышь", Decimal("1290.00"), 35),
            ]
        )

    def ping(self) -> None:
        return None

    def list_products(self, limit: int, offset: int) -> list[Product]:
        items = sorted(self._products.values(), key=lambda p: p.id)
        return items[offset : offset + limit]

    def get_product(self, product_id: int) -> Product | None:
        return self._products.get(product_id)

    def create_order(self, customer_id: int, items: list[tuple[int, int]]) -> Order:
        with self._lock:  # проверка и списание — одна неделимая операция
            if self._customers is not None and customer_id not in self._customers:
                raise InvalidOrder(f"покупатель {customer_id} не найден")
            for product_id, qty in items:  # сначала всё проверить: либо весь заказ, либо ничего
                product = self._products.get(product_id)
                if product is None:
                    raise ProductNotFound(product_id)
                if product.stock < qty:
                    raise OutOfStock(product_id)
            lines = []
            for product_id, qty in items:
                p = self._products[product_id]
                self._products[product_id] = Product(p.id, p.store_id, p.title, p.price, p.stock - qty)
                lines.append(OrderLine(p.id, p.title, p.price, qty))
            order = Order(customer_id, lines, id=len(self._orders) + 1)
            self._orders.append(order)
            return order


class PostgresRepository:
    """Хранилище в PostgreSQL. Схема — db/schema.sql.

    TODO (P1): соединение открывается на каждый запрос — для учебной нагрузки этого хватает.
    Под настоящей нагрузкой нужен пул соединений (psycopg_pool).
    """

    def __init__(self, dsn: str):
        import psycopg  # импорт здесь: тестам без базы драйвер не нужен

        self._psycopg = psycopg
        self.dsn = dsn

    def _connect(self):
        return self._psycopg.connect(self.dsn, connect_timeout=3)

    def ping(self) -> None:
        with self._connect() as conn:
            conn.execute("SELECT 1")

    def list_products(self, limit: int, offset: int) -> list[Product]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, store_id, title, price, stock FROM product ORDER BY id LIMIT %s OFFSET %s", (limit, offset)
            ).fetchall()
        return [Product(*row) for row in rows]

    def get_product(self, product_id: int) -> Product | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, store_id, title, price, stock FROM product WHERE id = %s", (product_id,)
            ).fetchone()
        return Product(*row) if row else None

    def create_order(self, customer_id: int, items: list[tuple[int, int]]) -> Order:
        # Блок with — одна транзакция: при любом исключении все списания откатываются.
        with self._connect() as conn, conn.cursor() as cur:
            lines = []
            for product_id, qty in items:
                # Атомарное списание: остаток проверяется и уменьшается одной командой,
                # поэтому два одновременных заказа не продадут один товар дважды (урок 2.10).
                cur.execute(
                    "UPDATE product SET stock = stock - %s WHERE id = %s AND stock >= %s " "RETURNING title, price",
                    (qty, product_id, qty),
                )
                row = cur.fetchone()
                if row is None:
                    cur.execute("SELECT 1 FROM product WHERE id = %s", (product_id,))
                    if cur.fetchone() is None:
                        raise ProductNotFound(product_id)
                    raise OutOfStock(product_id)
                lines.append(OrderLine(product_id, row[0], row[1], qty))
            order = Order(customer_id, lines)
            try:
                cur.execute(
                    "INSERT INTO orders (customer_id, total) VALUES (%s, %s) RETURNING id", (customer_id, order.total)
                )
            except self._psycopg.errors.ForeignKeyViolation:
                raise InvalidOrder(f"покупатель {customer_id} не найден") from None
            order.id = cur.fetchone()[0]
            cur.executemany(
                "INSERT INTO order_line (order_id, product_id, qty, price) VALUES (%s, %s, %s, %s)",
                [(order.id, line.product_id, line.qty, line.price) for line in lines],
            )
            return order
