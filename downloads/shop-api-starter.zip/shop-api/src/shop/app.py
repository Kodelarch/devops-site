"""HTTP-слой: маршруты, коды ответов, health-check, метрики и логи в JSON."""

import json
import logging
import sys
import time
import uuid
from datetime import UTC, datetime

from flask import Flask, Response, g, jsonify, request
from prometheus_client import CONTENT_TYPE_LATEST, CollectorRegistry, Counter, Histogram, generate_latest

from .config import Settings
from .domain import InvalidOrder, OrderService, OutOfStock, ProductNotFound
from .repository import InMemoryRepository, PostgresRepository


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        entry = {
            "ts": datetime.now(UTC).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "msg": record.getMessage(),
        }
        entry.update(getattr(record, "extra_fields", {}))
        return json.dumps(entry, ensure_ascii=False)


def product_to_web(p) -> dict:
    """Маппер домен -> клиент: точный остаток наружу не отдаём, только «в наличии»."""
    return {"id": p.id, "title": p.title, "price": str(p.price), "in_stock": p.stock > 0}


def create_app(repository=None, settings: Settings | None = None) -> Flask:
    settings = settings or Settings.from_env()
    if repository is None:
        repository = PostgresRepository(settings.database_url) if settings.database_url else InMemoryRepository.demo()
    orders = OrderService(repository)

    app = Flask(__name__)
    log = logging.getLogger("shop")
    if not log.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JsonFormatter())
        log.addHandler(handler)
    log.setLevel(settings.log_level)

    registry = CollectorRegistry()
    requests_total = Counter(
        "http_requests_total", "Число запросов", ["method", "endpoint", "status"], registry=registry
    )
    latency = Histogram(
        "http_request_duration_seconds",
        "Время ответа",
        ["endpoint"],
        registry=registry,
        buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5],
    )

    @app.before_request
    def start_timer():
        g.start = time.perf_counter()
        g.request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12]

    @app.after_request
    def observe(response):
        endpoint = request.url_rule.rule if request.url_rule else "unknown"  # шаблон маршрута, а не путь
        elapsed = time.perf_counter() - g.start
        if endpoint != "/metrics":
            requests_total.labels(request.method, endpoint, response.status_code).inc()
            latency.labels(endpoint).observe(elapsed)
            log.info(
                "request",
                extra={
                    "extra_fields": {
                        "request_id": g.request_id,
                        "method": request.method,
                        "path": request.path,
                        "status": response.status_code,
                        "ms": round(elapsed * 1000, 1),
                    }
                },
            )
        response.headers["X-Request-ID"] = g.request_id
        return response

    @app.errorhandler(InvalidOrder)
    def invalid(e):
        return jsonify(error="invalid_request", message=str(e)), 400

    @app.errorhandler(ProductNotFound)
    def not_found(e):
        return jsonify(error="product_not_found", message=str(e)), 404

    @app.errorhandler(OutOfStock)
    def out_of_stock(e):
        return jsonify(error="out_of_stock", message=str(e)), 409

    @app.get("/healthz")
    def healthz():
        """Процесс жив. Зависимости не проверяем, иначе перезапуски пойдут по кругу."""
        return {"status": "ok"}

    @app.get("/readyz")
    def readyz():
        """Готов принимать трафик: база отвечает."""
        try:
            repository.ping()
        except Exception as e:  # noqa: BLE001 — любая ошибка базы = не готов
            log.warning("readiness failed", extra={"extra_fields": {"error": type(e).__name__}})
            return {"status": "not ready", "reason": "database"}, 503
        return {"status": "ready"}

    @app.get("/metrics")
    def metrics():
        return Response(generate_latest(registry), mimetype=CONTENT_TYPE_LATEST)

    @app.get("/products")
    def list_products():
        limit = min(max(request.args.get("limit", 20, type=int), 1), 100)
        offset = max(request.args.get("offset", 0, type=int), 0)
        return jsonify(items=[product_to_web(p) for p in repository.list_products(limit, offset)])

    @app.get("/products/<int:product_id>")
    def get_product(product_id):
        product = repository.get_product(product_id)
        if product is None:
            raise ProductNotFound(product_id)
        return jsonify(product_to_web(product))

    @app.post("/orders")
    def create_order():
        body = request.get_json(silent=True) or {}
        order = orders.place_order(body.get("customer_id"), body.get("items"))
        return jsonify(order_id=order.id, total=str(order.total), status="created"), 201

    # TODO (P1): ключ идемпотентности для POST /orders (урок 2.5, §7).
    # TODO (P1): эндпоинт /reports с выручкой по магазинам (уроки 2.7 и 2.9).
    return app
