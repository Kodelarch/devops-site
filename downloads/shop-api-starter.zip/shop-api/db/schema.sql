-- Учебная база «маркетплейс электроники» для уроков 2.6–2.11.
-- В Docker Compose файл выполняется автоматически при первом запуске базы.

DROP TABLE IF EXISTS order_line, orders, purchase, store_visit, product, customer, store CASCADE;

CREATE TABLE store (
    id      bigint PRIMARY KEY,
    name    varchar NOT NULL,
    rating  numeric(2,1) NOT NULL DEFAULT 0 CHECK (rating BETWEEN 0 AND 5)
);

CREATE TABLE customer (
    id       bigint PRIMARY KEY,
    name     varchar NOT NULL,
    age      integer CHECK (age > 0),
    city     varchar,
    premium  boolean NOT NULL DEFAULT false
);

CREATE TABLE product (
    id        bigint PRIMARY KEY,
    store_id  bigint NOT NULL REFERENCES store(id),
    title     varchar NOT NULL,
    price     numeric(10,2) NOT NULL CHECK (price > 0),
    stock     integer NOT NULL DEFAULT 0 CHECK (stock >= 0)
);

CREATE TABLE store_visit (
    id           bigint PRIMARY KEY,
    customer_id  bigint NOT NULL REFERENCES customer(id),
    store_id     bigint NOT NULL REFERENCES store(id),
    visit_date   date NOT NULL
);

CREATE TABLE purchase (
    id             bigint PRIMARY KEY,
    customer_id    bigint NOT NULL REFERENCES customer(id),
    product_id     bigint NOT NULL REFERENCES product(id),
    purchase_date  date NOT NULL
);

INSERT INTO store VALUES
 (1, 'Гигабайт', 4.6), (2, 'Розетка+', 3.9), (3, 'ТехноДом', 4.2), (4, 'Пиксель', 4.8),
 (5, 'Кабель и Ко', 3.1), (6, 'Серверная', 4.4), (7, 'Умный дом', 3.6), (8, 'Новый магазин', 0.0);

INSERT INTO customer VALUES
 (1, 'Анна', 27, 'Москва', true),   (2, 'Борис', 34, 'Казань', false),
 (3, 'Вера', 19, 'Москва', false),  (4, 'Глеб', 45, 'Новосибирск', true),
 (5, 'Дарья', 31, 'Казань', true),  (6, 'Егор', 23, 'Москва', false),
 (7, 'Жанна', 52, 'Екатеринбург', false), (8, 'Иван', 16, 'Казань', false),
 (9, 'Ксения', 38, NULL, true),     (10, 'Лев', 67, 'Москва', false),
 (11, 'Мария', NULL, 'Новосибирск', false), (12, 'Никита', 29, 'Екатеринбург', true);

INSERT INTO product VALUES
 (1, 1, 'SSD 1 ТБ', 7490, 12), (2, 1, 'Оперативная память 16 ГБ', 3990, 30), (3, 1, 'Видеокарта', 54990, 5),
 (4, 2, 'Удлинитель', 890, 40), (5, 2, 'Сетевой фильтр', 1490, 25), (6, 2, 'ИБП 650 ВА', 6990, 8),
 (7, 3, 'Роутер Wi-Fi 6', 5490, 15), (8, 3, 'Коммутатор 8 портов', 2990, 20), (9, 3, 'Сетевой кабель 5 м', 390, 100),
 (10, 4, 'Монитор 27"', 21990, 6), (11, 4, 'Клавиатура', 3490, 18), (12, 4, 'Мышь', 1290, 35), (13, 4, 'Веб-камера', 4290, 9),
 (14, 5, 'Сетевой кабель 5 м', 290, 150), (15, 5, 'Кабель HDMI', 590, 60), (16, 5, 'Кабель USB-C', 490, 80),
 (17, 6, 'Мини-ПК для домашнего сервера', 32990, 3), (18, 6, 'Жёсткий диск 4 ТБ', 9990, 14), (19, 6, 'NAS на 2 диска', 24990, 4),
 (20, 7, 'Умная розетка', 1190, 50), (21, 7, 'Датчик протечки', 1590, 22), (22, 7, 'Умная лампа', 990, 45);

INSERT INTO store_visit VALUES
 (1, 1, 1, '2026-03-01'), (2, 1, 4, '2026-03-01'), (3, 2, 2, '2026-03-02'), (4, 2, 3, '2026-03-02'),
 (5, 3, 4, '2026-03-02'), (6, 4, 6, '2026-03-03'), (7, 4, 1, '2026-03-03'), (8, 5, 7, '2026-03-04'),
 (9, 5, 4, '2026-03-04'), (10, 6, 5, '2026-03-04'), (11, 6, 3, '2026-03-05'), (12, 7, 2, '2026-03-05'),
 (13, 8, 4, '2026-03-06'), (14, 9, 6, '2026-03-06'), (15, 9, 1, '2026-03-07'), (16, 10, 2, '2026-03-07'),
 (17, 12, 6, '2026-03-08'), (18, 12, 3, '2026-03-08'), (19, 1, 4, '2026-03-09'), (20, 3, 5, '2026-03-09'),
 (21, 4, 6, '2026-03-10'), (22, 2, 1, '2026-03-10'), (23, 5, 7, '2026-03-10'), (24, 11, 3, '2026-03-10');

INSERT INTO purchase VALUES
 (1, 1, 1, '2026-03-01'), (2, 1, 12, '2026-03-01'), (3, 2, 5, '2026-03-02'), (4, 2, 7, '2026-03-02'),
 (5, 3, 11, '2026-03-02'), (6, 4, 17, '2026-03-03'), (7, 4, 18, '2026-03-03'), (8, 5, 20, '2026-03-04'),
 (9, 5, 21, '2026-03-04'), (10, 6, 14, '2026-03-04'), (11, 7, 4, '2026-03-05'), (12, 8, 12, '2026-03-06'),
 (13, 9, 18, '2026-03-06'), (14, 9, 2, '2026-03-07'), (15, 12, 19, '2026-03-08'), (16, 12, 8, '2026-03-08'),
 (17, 1, 10, '2026-03-09'), (18, 3, 15, '2026-03-09'), (19, 4, 18, '2026-03-10'), (20, 2, 1, '2026-03-10'),
 (21, 5, 22, '2026-03-10'), (22, 6, 9, '2026-03-11'), (23, 10, 6, '2026-03-11'), (24, 12, 9, '2026-03-12');

-- Таблицы заказов приложения shop-api
CREATE TABLE orders (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id  bigint NOT NULL REFERENCES customer(id),
    total        numeric(12,2) NOT NULL CHECK (total >= 0),
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE order_line (
    order_id    bigint NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id  bigint NOT NULL REFERENCES product(id),
    qty         integer NOT NULL CHECK (qty > 0),
    price       numeric(10,2) NOT NULL,
    PRIMARY KEY (order_id, product_id)
);

CREATE INDEX idx_orders_customer ON orders (customer_id);
