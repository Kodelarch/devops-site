# shop-api — стартовый каркас для проекта P1

API магазина электроники: каталог товаров и оформление заказа с проверкой остатков на складе. Это точка старта для проекта P1 «Сервис на одном сервере» из курса «DevOps-маршрут».

Каркас уже умеет работать: слоистая архитектура, health-check, метрики, логи в JSON, тесты, Dockerfile и стенд в Docker Compose. Всё, что отмечено `TODO (P1)`, ты делаешь сама — это и есть проект.

> Прежде чем публиковать репозиторий, перепиши этот README под себя: что ты сделала, схема, как запустить, какие решения приняла и почему. Каркас — не портфолио, портфолио — то, что ты из него сделаешь.

## Что внутри

```
src/shop/
  domain.py       понятия и правила: товар, заказ, проверка позиций, ошибки домена
  repository.py   хранилища: в памяти (тесты, демо) и PostgreSQL с атомарным списанием остатков
  app.py          HTTP: маршруты, коды ответов, /healthz, /readyz, /metrics, логи в JSON
  config.py       настройки из переменных окружения
tests/            тесты без базы и сети
db/schema.sql     схема и учебные данные (та же база, что в SQL-уроках) + таблицы заказов
Dockerfile        multi-stage, slim, не root, HEALTHCHECK
compose.yaml      стенд: api + PostgreSQL + nginx
compose.prod.yaml дополнение для сервера: образ из реестра, автоперезапуск
.gitlab-ci.yml    lint → test → build → deploy (deploy — TODO)
```

## Быстрый старт

Без Docker, на демо-данных в памяти:

```bash
make install
make test
make run          # http://localhost:5000/products
```

Полный стенд с PostgreSQL и nginx:

```bash
cp .env.example .env      # и задай DB_PASSWORD
make up                   # http://localhost:8080/products
make logs
```

## API

| Метод и путь | Что делает | Коды ответа |
|---|---|---|
| `GET /healthz` | процесс жив | 200 |
| `GET /readyz` | база доступна, можно слать трафик | 200, 503 |
| `GET /metrics` | метрики Prometheus | 200 |
| `GET /products?limit=20&offset=0` | каталог | 200 |
| `GET /products/{id}` | товар | 200, 404 |
| `POST /orders` | оформить заказ | 201, 400, 404, 409 |

```bash
curl -s localhost:8080/products/3
curl -s -X POST localhost:8080/orders -H 'Content-Type: application/json' \
  -d '{"customer_id": 1, "items": [{"product_id": 3, "qty": 1}]}'
```

Заказ списывает остатки атомарно: два одновременных заказа последней видеокарты не пройдут оба — второй получит `409 out_of_stock`.

## Что сделать для P1

Полный чек-лист — на странице проекта P1 в курсе. Коротко:

- [ ] Сервер: Ubuntu, пользователь `deploy`, SSH только по ключу, ufw, UTC (можно взять свой скрипт из M1).
- [ ] HTTPS: сертификат и редирект в `nginx/default.conf` (`TODO`).
- [ ] CI/CD: включить стадию `deploy` в `.gitlab-ci.yml` (`TODO`), защищённые переменные, уведомления в Telegram, ручной откат на предыдущий тег.
- [ ] Бэкапы: `scripts/backup.sh` по cron с хранением 7 копий и проверенным восстановлением.
- [ ] Проверка доступности: `scripts/healthcheck.sh` с уведомлением.
- [ ] Логи: ограничение размера логов Docker.
- [ ] README: схема, решения, как восстановить базу.
- [ ] Бонус: ключ идемпотентности для `POST /orders` и эндпоинт `/reports` (`TODO` в `app.py`).
