from decimal import Decimal

import pytest

from shop.domain import InvalidOrder, OrderService, OutOfStock, Product, ProductNotFound, normalize_items
from shop.repository import InMemoryRepository


@pytest.fixture
def repo():
    return InMemoryRepository(
        [
            Product(1, 1, "SSD", Decimal("1000.00"), 3),
            Product(2, 1, "Мышь", Decimal("500.00"), 1),
        ],
        customers={1, 2},
    )


@pytest.fixture
def service(repo):
    return OrderService(repo)


def test_normalize_merges_duplicates_and_sorts():
    items = [{"product_id": 2, "qty": 1}, {"product_id": 1, "qty": 1}, {"product_id": 2, "qty": 2}]
    assert normalize_items(items) == [(1, 1), (2, 3)]


@pytest.mark.parametrize(
    "items", [None, [], [{"product_id": 1}], [{"product_id": 1, "qty": 0}], [{"product_id": "abc", "qty": 1}]]
)
def test_normalize_rejects_bad_items(items):
    with pytest.raises(InvalidOrder):
        normalize_items(items)


def test_order_total_and_stock(service, repo):
    order = service.place_order(1, [{"product_id": 1, "qty": 2}])
    assert order.total == Decimal("2000.00")
    assert repo.get_product(1).stock == 1


def test_out_of_stock_changes_nothing(service, repo):
    with pytest.raises(OutOfStock):
        service.place_order(1, [{"product_id": 1, "qty": 1}, {"product_id": 2, "qty": 5}])
    assert repo.get_product(1).stock == 3  # заказ не прошёл целиком — первый товар не списан


def test_unknown_product(service):
    with pytest.raises(ProductNotFound):
        service.place_order(1, [{"product_id": 99, "qty": 1}])


def test_unknown_customer(service):
    with pytest.raises(InvalidOrder):
        service.place_order(42, [{"product_id": 1, "qty": 1}])


def test_last_item_sold_once(service):
    service.place_order(1, [{"product_id": 2, "qty": 1}])
    with pytest.raises(OutOfStock):
        service.place_order(2, [{"product_id": 2, "qty": 1}])
