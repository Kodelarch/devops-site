from decimal import Decimal

import pytest

from shop.app import create_app
from shop.config import Settings
from shop.domain import Product
from shop.repository import InMemoryRepository


class BrokenRepository(InMemoryRepository):
    def ping(self):
        raise ConnectionError("база недоступна")


@pytest.fixture
def client():
    repo = InMemoryRepository([Product(3, 1, "Видеокарта", Decimal("54990.00"), 1)])
    app = create_app(repo, Settings(database_url=None))
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_healthz(client):
    assert client.get("/healthz").status_code == 200


def test_readyz_fails_when_database_is_down():
    app = create_app(BrokenRepository([]), Settings(database_url=None))
    response = app.test_client().get("/readyz")
    assert response.status_code == 503
    assert response.get_json()["reason"] == "database"


def test_product_hides_exact_stock(client):
    body = client.get("/products/3").get_json()
    assert body == {"id": 3, "title": "Видеокарта", "price": "54990.00", "in_stock": True}


def test_missing_product_is_404(client):
    response = client.get("/products/999")
    assert response.status_code == 404
    assert response.get_json()["error"] == "product_not_found"


def test_second_order_for_last_item_is_409(client):
    order = {"customer_id": 1, "items": [{"product_id": 3, "qty": 1}]}
    first = client.post("/orders", json=order)
    assert first.status_code == 201
    assert first.get_json()["total"] == "54990.00"
    second = client.post("/orders", json=order)
    assert second.status_code == 409
    assert second.get_json()["error"] == "out_of_stock"


def test_invalid_order_is_400(client):
    response = client.post("/orders", json={"customer_id": 1, "items": []})
    assert response.status_code == 400


def test_metrics_use_route_template(client):
    client.get("/products/3")
    text = client.get("/metrics").get_data(as_text=True)
    assert 'endpoint="/products/<int:product_id>"' in text
